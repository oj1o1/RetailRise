import axios from "axios";

export const axiosInstance = axios.create({
    baseURL:
        "https://e-shop-app.onrender.com",
});
