import React from "react";
import "./ButtonLoader.scss";

const ButtonLoader = () => {
    return <div className="lds-dual-ring"></div>;
};

export default ButtonLoader;
